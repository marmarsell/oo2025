package ee.Marsell.Libisev_keskmine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibisevKeskmineApplicationTests {

	@Test
	void contextLoads() {
	}

}

package ee.Marsell.Libisev_keskmine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibisevKeskmineApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibisevKeskmineApplication.class, args);
	}

}

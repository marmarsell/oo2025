package ee.marsell.kymnendvyistlus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KymnendvyistlusApplication {

	public static void main(String[] args) {
		SpringApplication.run(KymnendvyistlusApplication.class, args);
	}

}
